package c1.collection;

import java.util.Stack;
import java.util.Vector;

public class sv {
public static void main(String[] args) {
	Vector v=new Vector<>();
	v.add("aaa");
	v.add("vvv");
	v.add("bbb");
	v.add("xxx");
	System.out.println(v);
	Stack s=new Stack<>();
	s.push("one");
	
			
}
}
