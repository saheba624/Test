package c1.collection;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

public class queue {
public static void main(String[] args) {
	/*PriorityQueue p= new PriorityQueue<>();
	p.add(1);

	p.add(2.3);

	p.add(6);

	p.add('A');

	System.out.println(p);*/
	  Set hashSet = new HashSet();

	  hashSet.add(1);

	  hashSet.add("1");

	  hashSet.add(null);

	  hashSet.add("null");

	  System.out.println(hashSet);

}
}
