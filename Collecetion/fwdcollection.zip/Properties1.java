package c1.collection;

import java.util.Properties;

public class Properties1 {
	public static void main(String[] args) {
		Properties p=new Properties();
		p.put("1", "one");
		p.put("8", "two");
		p.put("7", "jj");
		p.put("9", "dd");
		System.out.println(p);
	}
	

}
