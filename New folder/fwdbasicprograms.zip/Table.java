package com.basic;

public class Table {
	public static void main(String[] args) {
		int no=7;
		
		for(int i=1;i<=10;i++){
			System.out.println(no*i);
		}
	}

}
