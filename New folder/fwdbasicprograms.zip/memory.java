package com.basic;

public class memory {
	protected void finalize(){
		System.out.println("memory is optimise");
	} 

}
