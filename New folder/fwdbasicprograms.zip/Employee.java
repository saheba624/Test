package com.basic;

public class Employee {
	
	protected Object clone(){
		return this;
	}

	
}
