package com.basic.pattern;

public class P8 {
	public static void main(String[] args) {
		
		
	}

}
