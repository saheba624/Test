package com.basic;

public class Ternary {
	public static void main(String[] args) {
		int a=30;
		int b=20;
		int c=(a<b)?b:a;
		System.out.println(c);
	}

}
