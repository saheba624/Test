package com.basic.pattern;

public class p1 {
public static void main(String[] args) {
	for(int i=5;i>=1;i--){
		for(int j=1;j<=i;j++){
			System.out.print("*");
		}
		System.out.println("");
	}
	for(int k=2;k<=5;k++){
		for(int l=1;l<=k;l++){
			System.out.print("*");
		}
		System.out.println("");
	}
}
}
